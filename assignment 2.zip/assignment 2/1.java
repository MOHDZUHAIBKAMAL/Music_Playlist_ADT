class SongNode {
    String songTitle;
    String artist;
    String movie;
    SongNode next;
    SongNode previous;
    
    public SongNode(String songTitle, String artist, String movie) {
        this.songTitle = songTitle;
        this.artist = artist;
        this.movie = movie;
    }
}

public class Playlist {
    static void displayPlaylistForward(SongNode head) {
        SongNode ptr = head;
        do {
            System.out.println(ptr.songTitle);
            System.out.println(ptr.artist);
            System.out.println(ptr.movie);
            System.out.println();
            ptr = ptr.next;
        } while (ptr != head);
    }

    static void displayPlaylistBackward(SongNode playlistTail) {
        SongNode ptr = playlistTail;
        for (int i = 4; i > 0; i--) {
            System.out.println(ptr.songTitle);
            System.out.println(ptr.artist);
            System.out.println(ptr.movie);
            ptr = ptr.previous;
            System.out.println();
        }
    }

    static void insertSong(SongNode head, String songTitle, String artist, String movie) {
        SongNode p = head;
        SongNode ptr = new SongNode(songTitle, artist, movie);

        while (p.next != head) {
            p = p.next;
        }

        p.next = ptr;
        ptr.next = head;
        ptr.previous = p;
        head.previous = ptr;

        displayPlaylistForward(head);
    }

    static void deleteSong(SongNode head, int index) {
        SongNode p = head;
        SongNode q = head.next;

        for (int i = 0; i < index - 1; i++) {
            p = p.next;
            q = q.next;
        }
        p.next = q.next;

        displayPlaylistForward(head);
    }

    static void playingSongDetails(SongNode song) {
        System.out.println(song.songTitle);
        System.out.println(song.artist);
        System.out.println(song.movie);
    }

    static void loop(SongNode head, SongNode song) {
        SongNode p = song;
        do {
            p = p.next;
        } while (p.next != head);

        SongNode ptr = head;

        while (true) {
            System.out.println(ptr.songTitle);
            System.out.println(ptr.artist);
            System.out.println(ptr.movie);
            System.out.println();
            ptr = ptr.next;
        }
    }

    static void repeatCurrentSong(SongNode song) {
        while (true) {
            System.out.println(song.songTitle);
            System.out.println(song.artist);
            System.out.println(song.movie);
            System.out.println();
        }
    }

    static void shuffle(SongNode head, SongNode secondSong, SongNode thirdSong, SongNode lastSong) {
        SongNode p = secondSong;
        secondSong = lastSong;
        lastSong = head;
        head = thirdSong;
        thirdSong = p;

        SongNode ptr = head;
        do {
            System.out.println(ptr.songTitle);
            System.out.println(ptr.artist);
            System.out.println(ptr.movie);
            System.out.println();
            ptr = ptr.next;
        } while (ptr != head);
    }

    public static void main(String[] args) {
        SongNode playlistHead = new SongNode("Bum Bum Bole", "Aamir Khan", "Taare Zameen Par");
        SongNode secondSong = new SongNode("Aasman Ko Chukar Dekha", "Daler Mehndi", "Return Of Hanuman");
        SongNode thirdSong = new SongNode("Namo Namo", "Sushant Singh", "Kedarnath");
        SongNode playlistTail = new SongNode("Taare Zameen Par", "Aamir Khan", "Taare Zameen Par");

        playlistHead.next = secondSong;
        playlistHead.previous = playlistTail;

        secondSong.next = thirdSong;
        secondSong.previous = playlistHead;

        thirdSong.next = playlistTail;
        thirdSong.previous = secondSong;

        playlistTail.next = playlistHead;
        playlistTail.previous = thirdSong;

        displayPlaylistForward(playlistHead);
        
        // Insertion, deletion, and other operations can be called here
    }
}
