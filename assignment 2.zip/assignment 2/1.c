#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct SongNode
{
    char SongTitle[25];
    char Artist[25];
    char Movie[25];
    struct SongNode *next;
    struct SongNode *previous;
};

int display_playlist_forward(struct SongNode *head)
{
    struct SongNode *ptr = (struct SongNode *)malloc(sizeof(struct SongNode));
    ptr = head;
    do
    {
        printf("%s\n", ptr->SongTitle);
        printf("%s\n", ptr->Artist);
        printf("%s\n", ptr->Movie);
        printf("\n");
        ptr = ptr->next;
    } while (ptr != head);
}

int display_playlist_backward(struct SongNode *playlist_tail)
{
    struct SongNode *ptr = (struct SongNode *)malloc(sizeof(struct SongNode));
    ptr = playlist_tail;

    for (int i = 4; i > 0; i--)
    {
        printf("%s\n", ptr->SongTitle);
        printf("%s\n", ptr->Artist);
        printf("%s\n", ptr->Movie);
        ptr = ptr->previous;
        printf("\n");
    }
}

int insert_song(struct SongNode *head, char *SongTitle, char *Artist, char *Movie)
{
    struct SongNode *p = (struct SongNode *)malloc(sizeof(struct SongNode));
    p = head;
    struct SongNode *ptr = (struct SongNode *)malloc(sizeof(struct SongNode));

    strcpy(ptr->SongTitle, SongTitle);
    strcpy(ptr->Artist, Artist);
    strcpy(ptr->Movie, Movie);

    do
    {
        p = p->next;
    } while (p->next != head);

    p->next = ptr;
    ptr->next = head;
    ptr->previous = p;
    head->previous = ptr;

    display_playlist_forward(head);

    // do
    // {
    //     printf("%s\n", ptr->SongTitle);
    //     printf("%s\n", ptr->Artist);
    //     printf("%s\n", ptr->Movie);
    //     printf("\n");
    //     ptr = ptr->next;
    // } while (ptr != head);
}

int delete_song(struct SongNode *head, int index)
{
    struct SongNode *p = (struct SongNode *)malloc(sizeof(struct SongNode));
    p = head;
    struct SongNode *q = (struct SongNode *)malloc(sizeof(struct SongNode));
    q = head->next;

    for (int i = 0; i < index - 1; i++)
    {
        p = p->next;
        q = q->next;
    }
    p->next = q->next;
    free(q);

    display_playlist_forward(head);
}

int playing_song_details(struct SongNode *song)
{
    printf("%s\n", song->SongTitle);
    printf("%s\n", song->Artist);
    printf("%s\n", song->Movie);
}

int loop(struct SongNode *head, struct SongNode *song)
{
    struct SongNode *p = (struct SongNode *)malloc(sizeof(struct SongNode));
    p = song;
    do
    {
        p = p->next;
    } while (p->next != head);

    struct SongNode *ptr = (struct SongNode *)malloc(sizeof(struct SongNode));
    ptr = head;

    for (;;)
    {
        printf("%s\n", ptr->SongTitle);
        printf("%s\n", ptr->Artist);
        printf("%s\n", ptr->Movie);
        printf("\n");
        ptr = ptr->next;
    }
}

int repeat_current_song(struct SongNode *song)
{
    for (;;)
    {
        printf("%s\n", song->SongTitle);
        printf("%s\n", song->Artist);
        printf("%s\n", song->Movie);
        printf("\n");
    }
}

int shuffle(struct SongNode *head, struct SongNode *secondsong, struct SongNode *thirdsong, struct SongNode *lastsong)
{
    struct SongNode *p = (struct SongNode *)malloc(sizeof(struct SongNode));
    p = secondsong;
    secondsong = lastsong;
    lastsong = head;
    head = thirdsong;
    thirdsong = p;

    struct SongNode *ptr = (struct SongNode *)malloc(sizeof(struct SongNode));
    ptr = head;
    do
    {
        printf("%s\n", ptr->SongTitle);
        printf("%s\n", ptr->Artist);
        printf("%s\n", ptr->Movie);
        printf("\n");
        ptr = ptr->next;
    } while (ptr != head);
}

int main()
{
    struct SongNode *playlist_head = (struct SongNode *)malloc(sizeof(struct SongNode));
    struct SongNode *second_song = (struct SongNode *)malloc(sizeof(struct SongNode));
    struct SongNode *third_song = (struct SongNode *)malloc(sizeof(struct SongNode));
    struct SongNode *playlist_tail = (struct SongNode *)malloc(sizeof(struct SongNode));

    strcpy(playlist_head->SongTitle, "Bum Bum Bole");
    strcpy(playlist_head->Artist, "Aamir Khan");
    strcpy(playlist_head->Movie, "Taare Zameen Par");
    playlist_head->next = second_song;
    playlist_head->previous = playlist_tail;

    strcpy(second_song->SongTitle, "Aasman Ko Chukar Dekha");
    strcpy(second_song->Artist, "Daler Mehndi");
    strcpy(second_song->Movie, "Return Of Hanuman");
    second_song->next = third_song;
    second_song->previous = playlist_head;

    strcpy(third_song->SongTitle, "Namo Namo");
    strcpy(third_song->Artist, "Sushant Singh");
    strcpy(third_song->Movie, "Kedarnath");
    third_song->next = playlist_tail;
    third_song->previous = second_song;

    strcpy(playlist_tail->SongTitle, "Taare Zameen Par");
    strcpy(playlist_tail->Artist, "Aamir Khan");
    strcpy(playlist_tail->Movie, "Taare Zameen Par");
    playlist_tail->next = playlist_head;
    playlist_tail->previous = third_song;

    display_playlist_forward(playlist_head);

    // insert_song(playlist_head, "All Is Well", "Aamir Khan", "Three Idiots");

    // delete_song(playlist_head, 2);

    // traverse_playlist_backward(playlist_tail);

    // playing_song_details(second_song);

    // loop(playlist_head, third_song);

    // repeat_current_song(playlist_head);

    // printf("\n\n");
    // shuffle(playlist_head, second_song, third_song, playlist_tail);

    free(playlist_head);
    free(second_song);
    free(third_song);
    free(playlist_tail);
}
