#include <iostream>
#include <string>
using namespace std;

class SongNode {
public:
    string SongTitle;
    string Artist;
    string Movie;
    SongNode* next;
    SongNode* previous;

    SongNode(string title, string artist, string movie) {
        SongTitle = title;
        Artist = artist;
        Movie = movie;
        next = nullptr;
        previous = nullptr;
    }
};

class Playlist {
private:
    SongNode* head;
    SongNode* tail;

public:
    Playlist() {
        head = nullptr;
        tail = nullptr;
    }

    ~Playlist() {
        SongNode* current = head;
        while (current != nullptr) {
            SongNode* next = current->next;
            delete current;
            current = next;
        }
    }

    void displayPlaylistForward() {
        SongNode* ptr = head;
        do {
            cout << ptr->SongTitle << endl;
            cout << ptr->Artist << endl;
            cout << ptr->Movie << endl << endl;
            ptr = ptr->next;
        } while (ptr != head);
    }

    void displayPlaylistBackward() {
        SongNode* ptr = tail;
        for (int i = 4; i > 0; i--) {
            cout << ptr->SongTitle << endl;
            cout << ptr->Artist << endl;
            cout << ptr->Movie << endl << endl;
            ptr = ptr->previous;
        }
    }

    void insertSong(string title, string artist, string movie) {
        SongNode* ptr = head;
        SongNode* newNode = new SongNode(title, artist, movie);
        do {
            ptr = ptr->next;
        } while (ptr->next != head);

        ptr->next = newNode;
        newNode->next = head;
        newNode->previous = ptr;
        head->previous = newNode;

        displayPlaylistForward();
    }

    void deleteSong(int index) {
        SongNode* p = head;
        SongNode* q = head->next;
        for (int i = 0; i < index - 1; i++) {
            p = p->next;
            q = q->next;
        }
        p->next = q->next;
        delete q;

        displayPlaylistForward();
    }

    void playSongDetails(SongNode* song) {
        cout << song->SongTitle << endl;
        cout << song->Artist << endl;
        cout << song->Movie << endl;
    }

    void loop() {
        SongNode* p = head;
        do {
            p = p->next;
        } while (p->next != head);

        SongNode* ptr = head;
        for (;;) {
            cout << ptr->SongTitle << endl;
            cout << ptr->Artist << endl;
            cout << ptr->Movie << endl << endl;
            ptr = ptr->next;
        }
    }

    void repeatCurrentSong(SongNode* song) {
        for (;;) {
            cout << song->SongTitle << endl;
            cout << song->Artist << endl;
            cout << song->Movie << endl << endl;
        }
    }

    void shuffle(SongNode* secondSong, SongNode* thirdSong, SongNode* lastSong) {
        SongNode* p = secondSong;
        secondSong = lastSong;
        lastSong = head;
        head = thirdSong;
        thirdSong = p;

        SongNode* ptr = head;
        do {
            cout << ptr->SongTitle << endl;
            cout << ptr->Artist << endl;
            cout << ptr->Movie << endl << endl;
            ptr = ptr->next;
        } while (ptr != head);
    }

    void setHead(SongNode* h) {
        head = h;
    }

    void setTail(SongNode* t) {
        tail = t;
    }
};

int main() {
    Playlist playlist;
    SongNode* playlist_head = new SongNode("Bum Bum Bole", "Aamir Khan", "Taare Zameen Par");
    SongNode* second_song = new SongNode("Aasman Ko Chukar Dekha", "Daler Mehndi", "Return Of Hanuman");
    SongNode* third_song = new SongNode("Namo Namo", "Sushant Singh", "Kedarnath");
    SongNode* playlist_tail = new SongNode("Taare Zameen Par", "Aamir Khan", "Taare Zameen Par");

    playlist.setHead(playlist_head);
    playlist.setTail(playlist_tail);

    playlist_head->next = second_song;
    playlist_head->previous = playlist_tail;

    second_song->next = third_song;
    second_song->previous = playlist_head;

    third_song->next = playlist_tail;
    third_song->previous = second_song;

    playlist_tail->next = playlist_head;
    playlist_tail->previous = third_song;

    playlist.displayPlaylistForward();

    // playlist.insertSong("All Is Well", "Aamir Khan", "Three Idiots");

    // playlist.deleteSong(2);

    // playlist.displayPlaylistBackward();

    // playlist.playSongDetails(second_song);

    // playlist.loop();

    // playlist.repeatCurrentSong(playlist_head);

    playlist.shuffle(second_song, third_song, playlist_tail);

    delete playlist_head;
    delete second_song;
    delete third_song;
    delete playlist_tail;

    return 0;
}
